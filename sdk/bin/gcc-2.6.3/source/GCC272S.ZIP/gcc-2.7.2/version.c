char *version_string = "2.7.2.SN32.3.7 Build 0001";

