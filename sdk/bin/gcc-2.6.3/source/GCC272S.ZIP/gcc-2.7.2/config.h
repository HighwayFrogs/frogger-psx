#ifndef SNLIBGCC1
#include "i386/xm-winnt.h"
#else
#include "tconfig.h"
#endif
