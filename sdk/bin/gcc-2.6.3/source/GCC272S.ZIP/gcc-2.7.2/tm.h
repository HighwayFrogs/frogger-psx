/* Modified version of tm.h */
/* Gil 5.2.97 */
/* NEVER change or overwrite this - it selects which target configuration to use based on the #define 
you give in the build process. This is supplied in the relevant makefile. */


#if (defined(SNPSX) || defined(SNMIPS) || defined(SNN64) || defined(SNPPC))

#ifdef SNPSX
#include "mips/psx.h"
#endif

#ifdef SNMIPS
#include "mips/phoenix.h"
#endif

#ifdef SNN64
#include "mips/n64.h"
#endif

#ifdef SNPPC
#include "rs6000/snppc.h"
#endif

#else

#error SN-related build error - you forgot to define an SNtarget variable.

#endif

