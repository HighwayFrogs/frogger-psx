/* Definitions of target machine for GNU compiler.  Tandem S2 w/ NonStop UX
   using encapsulated stabs.  */
#define PREFERRED_DEBUGGING_TYPE DBX_DEBUG
#include "mips/svr4-t.h"
