/* Configuration for GCC for Motorola 68k running NetBSD as host.  */

#include <m68k/xm-m68k.h>
#include <xm-netbsd.h>
