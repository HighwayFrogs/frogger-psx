#include "m68k/sun3n.h"

/* LINK_SPEC is needed only for Sunos 4.  */

#undef LINK_SPEC
