/* Modified version of tconfig.h */
/* Gil 5.2.97 */
/* NEVER change or overwrite this - it selects which target configuration to use based on the #define 
you give in the build process. This is supplied in the relevant makefile. */

#ifdef SNPSX
#include "mips/xm-psx.h"
#endif

#ifdef SNMIPS
#include "mips/xm-phoenix.h"
#endif

#ifdef SNN64
#include "mips/xm-n64.h"
#endif

#ifdef SNPPC
#include "rs6000/xm-snppc.h"
#endif

#ifdef SNM68K
#include "m68k/xm-snm68k.h"
#endif
