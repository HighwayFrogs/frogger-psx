#ifndef _GLOBAL_H
#define _GLOBAL_H

#include <ctime>

namespace global {

	extern time_t	BuildTime;
	extern int		QuietMode;
	extern int		noXA;
	extern int		trackNum;
};

#endif // _GLOBAL_H
